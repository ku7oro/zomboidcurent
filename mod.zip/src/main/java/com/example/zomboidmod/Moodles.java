package com.example.zomboidmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/** Мудлы (значки состояния) как в PZ: у каждого 4 уровня, плохие - от жёлтого к тёмно-красному. */
public final class Moodles {
    public record Moodle(String icon, String name, String desc, int level, boolean good) {}

    private Moodles() {
    }

    public static List<Moodle> current(MinecraftClient c) {
        List<Moodle> out = new ArrayList<>();
        ClientPlayerEntity p = c.player;
        if (p == null) return out;

        // Жажда: пороги PZ 13 / 25 / 70 / 85 %
        int thirst = 100 - ZomboidClient.thirst();
        if (thirst > 85) out.add(new Moodle("thirst", "Умирает от жажды", "Нужна вода. Здоровье падает", 4, false));
        else if (thirst > 70) out.add(new Moodle("thirst", "Сильная жажда", "Слабость и головокружение", 3, false));
        else if (thirst > 25) out.add(new Moodle("thirst", "Жажда", "Нужно попить", 2, false));
        else if (thirst > 13) out.add(new Moodle("thirst", "Сухость во рту", "Скоро захочется пить", 1, false));

        // Голод: пороги PZ 15 / 25 / 45 / 70 %
        int food = p.getHungerManager().getFoodLevel();
        int hunger = (20 - food) * 5;
        if (hunger >= 70) out.add(new Moodle("hunger", "Истощение", "Здоровье скоро начнёт падать", 4, false));
        else if (hunger >= 45) out.add(new Moodle("hunger", "Сильный голод", "Сила снижена", 3, false));
        else if (hunger >= 25) out.add(new Moodle("hunger", "Голод", "Пора поесть", 2, false));
        else if (hunger >= 15) out.add(new Moodle("hunger", "Не прочь перекусить", "Можно бы и поесть", 1, false));
        else if (food >= 20 && p.getHungerManager().getSaturationLevel() >= 5)
            out.add(new Moodle("hunger", "Сыт", "Раны заживают быстрее", 1, true));

        // Кровотечение
        int bleed = ZomboidClient.bleedLevel();
        if (bleed == 3) out.add(new Moodle("bleeding", "Обильная кровопотеря", "Смерть близка. Перевяжите раны!", 4, false));
        else if (bleed == 2) out.add(new Moodle("bleeding", "Кровотечение", "Сила и скорость снижены", 2, false));
        else if (bleed == 1) out.add(new Moodle("bleeding", "Слабое кровотечение", "Нужна повязка", 1, false));

        // Травмы: по общему здоровью, пороги PZ 80 / 60 / 40 / 25 %
        float hp = p.getHealth() / p.getMaxHealth() * 100f;
        if (hp < 25) out.add(new Moodle("injured", "Критические травмы", "Не уйти тихо в эту ночь...", 4, false));
        else if (hp < 40) out.add(new Moodle("injured", "Тяжёлые травмы", "Сила и скорость сильно снижены", 3, false));
        else if (hp < 60) out.add(new Moodle("injured", "Травмирован", "Сила и скорость снижены", 2, false));
        else if (hp < 80) out.add(new Moodle("injured", "Дискомфорт", "Что-то не так...", 1, false));

        // Боль: пороги PZ 10 / 20 / 50 / 75
        int pain = ZomboidClient.pain();
        if (pain >= 75) out.add(new Moodle("pain", "Агония", "Скорость и точность сильно снижены", 4, false));
        else if (pain >= 50) out.add(new Moodle("pain", "Сильная боль", "Скорость и точность снижены", 3, false));
        else if (pain >= 20) out.add(new Moodle("pain", "Боль", "Скорость и точность немного снижены", 2, false));
        else if (pain >= 10) out.add(new Moodle("pain", "Слабая боль", "Немного болит", 1, false));

        // Болезнь: появляется не сразу после укуса
        int sick = ZomboidClient.sickLevel();
        if (sick == 4) out.add(new Moodle("sick", "Лихорадка", "Тело горит. Конец близок", 4, false));
        else if (sick == 3) out.add(new Moodle("sick", "Тошнит", "Очень плохо", 3, false));
        else if (sick == 2) out.add(new Moodle("sick", "Нездоровится", "Озноб и слабость", 2, false));
        else if (sick == 1) out.add(new Moodle("sick", "Подташнивает", "Что-то не так с самочувствием", 1, false));
        return out;
    }

    /** Цвет фона значка. */
    public static int color(Moodle m) {
        if (m.good()) return 0xFF3E7D3A;
        return switch (m.level()) {
            case 1 -> 0xFF8A7B2E;
            case 2 -> 0xFFA25A1E;
            case 3 -> 0xFF9A2A1E;
            default -> 0xFF5E0E10;
        };
    }
}
