package com.example.zomboidmod.block;

import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.world.Loot;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.LinkedHashMap;
import java.util.Map;

/** Регистрация мебели (список сгенерирован из gen_furniture.py вместе с моделями). */
public final class ZomboidBlocks {
    public static final Map<String, FurnitureBlock> FURNITURE = new LinkedHashMap<>();
    public static Block FURNITURE_TOP;
    public static Block LOOT_PILE;
    public static BlockEntityType<FurnitureBlockEntity> FURNITURE_BE;
    public static BlockEntityType<LootPileBlockEntity> LOOT_PILE_BE;

    private ZomboidBlocks() {
    }

    public static FurnitureBlock get(String id) {
        return FURNITURE.get(id);
    }

    private static void reg(String id, int rows, boolean tall, Loot loot, double[] box) {
        AbstractBlock.Settings s = AbstractBlock.Settings.create().strength(1.5f).nonOpaque()
                .sounds(id.contains("shelf") || id.contains("trash") || id.equals("stove") || id.equals("fridge")
                        || id.equals("washing_machine") ? BlockSoundGroup.METAL : BlockSoundGroup.WOOD);
        FurnitureBlock b = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, id), new FurnitureBlock(s, rows, tall, loot, box));
        Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), new BlockItem(b, new Item.Settings()));
        FURNITURE.put(id, b);
    }

    public static void register() {
        FURNITURE_TOP = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "furniture_top"),
                new FurnitureTopBlock(AbstractBlock.Settings.create().strength(1.5f).nonOpaque().dropsNothing()));
        LOOT_PILE = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "loot_pile"),
                new LootPileBlock(AbstractBlock.Settings.create().strength(0.1f).nonOpaque().noCollision().dropsNothing()));
        reg("fridge", 3, true, Loot.FRIDGE, new double[]{1, 0, 1, 15, 16, 16});
        reg("stove", 1, false, Loot.KITCHEN, new double[]{0, 0, 1, 16, 16, 16});
        reg("kitchen_counter", 2, false, Loot.KITCHEN, new double[]{0, 0, 0.5, 16, 16, 16});
        reg("kitchen_sink", 1, false, Loot.KITCHEN, new double[]{0, 0, 0.5, 16, 16, 16});
        reg("kitchen_table", 0, false, null, new double[]{0, 0, 0, 16, 15, 16});
        reg("chair", 0, false, null, new double[]{2.5, 0, 2.5, 13.5, 16, 13.5});
        reg("sofa", 0, false, null, new double[]{0, 0, 1, 16, 16, 16});
        reg("armchair", 0, false, null, new double[]{0, 0, 1, 16, 16, 16});
        reg("tv", 0, false, null, new double[]{1, 0, 3, 15, 16, 16});
        reg("wardrobe", 3, true, Loot.BEDROOM, new double[]{0, 0, 0.5, 16, 16, 16});
        reg("nightstand", 1, false, Loot.BEDROOM, new double[]{1.5, 0, 1.5, 14.5, 16, 14.5});
        reg("dresser", 2, false, Loot.BEDROOM, new double[]{0, 0, 1.5, 16, 16, 15.5});
        reg("toilet", 0, false, null, new double[]{2.5, 0, 1.5, 13.5, 16, 16});
        reg("bathtub", 0, false, null, new double[]{0, 0, 0, 16, 14, 16});
        reg("bathroom_sink", 1, false, Loot.BATHROOM, new double[]{2, 0, 4, 14, 16, 16});
        reg("washing_machine", 0, false, null, new double[]{1, 0, 1, 15, 16, 15});
        reg("floor_lamp", 0, false, null, new double[]{4, 0, 4, 12, 16, 12});
        reg("desk", 2, false, Loot.OFFICE, new double[]{0, 0, 0, 16, 16, 16});
        reg("shelf_food", 3, false, Loot.GROCERY, new double[]{0, 0, 1, 16, 16, 16});
        reg("shelf_meds", 3, false, Loot.PHARMACY, new double[]{0, 0, 1, 16, 16, 16});
        reg("shelf_tools", 3, false, Loot.HARDWARE, new double[]{0, 0, 1, 16, 16, 16});
        reg("trash_can", 1, false, Loot.TRASH, new double[]{3.5, 0, 3.5, 12.5, 14, 12.5});
        reg("radio", 0, false, null, new double[]{3, 0, 5, 13, 15, 11});
        reg("cardboard_box", 1, false, Loot.WAREHOUSE, new double[]{1, 0, 1, 15, 12, 15});
        FURNITURE_BE = Registry.register(Registries.BLOCK_ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "furniture"),
                BlockEntityType.Builder.create(FurnitureBlockEntity::new,
                        FURNITURE.values().stream().filter(f -> f.rows > 0).toArray(Block[]::new)).build(null));
        LOOT_PILE_BE = Registry.register(Registries.BLOCK_ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "loot_pile"),
                BlockEntityType.Builder.create(LootPileBlockEntity::new, LOOT_PILE).build(null));

        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(FURNITURE.get("fridge")))
                .displayName(Text.translatable("itemGroup.zomboidmod.furniture"))
                .entries((ctx, entries) -> FURNITURE.values().forEach(entries::add))
                .build();
        Registry.register(Registries.ITEM_GROUP, Identifier.of(ZomboidMod.MOD_ID, "furniture"), group);
    }
}
