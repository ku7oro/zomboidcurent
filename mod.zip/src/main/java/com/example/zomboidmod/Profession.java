package com.example.zomboidmod;

import java.util.EnumMap;
import java.util.Map;

/** Профессии и стартовые уровни навыков (по Project Zomboid, без навыков, которых нет в моде). */
public enum Profession {
    UNEMPLOYED(8, "Безработный", "Ни особых умений, ни привычек. Всему придётся учиться с нуля."),
    BURGER_FLIPPER(2, "Повар фастфуда", "Жарил котлеты и резал овощи на скорость.",
            PzSkill.COOKING, 2, PzSkill.MAINTENANCE, 1, PzSkill.SHORT_BLADE, 1),
    CHEF(-2, "Шеф-повар", "Кухня ресторана приучила к ножу и к порядку.",
            PzSkill.COOKING, 4, PzSkill.MAINTENANCE, 1, PzSkill.SHORT_BLADE, 1),
    DOCTOR(0, "Врач", "Знает, как зашить рану и не занести инфекцию.",
            PzSkill.FIRST_AID, 6, PzSkill.SHORT_BLADE, 1),
    NURSE(0, "Медсестра", "Ночные смены на ногах и уверенная перевязка.",
            PzSkill.FITNESS, 6, PzSkill.FIRST_AID, 3, PzSkill.LIGHTFOOTED, 1),
    FARMER(0, "Фермер", "Земля кормила его всю жизнь, руки крепкие.",
            PzSkill.STRENGTH, 6, PzSkill.FARMING, 4),
    FIREFIGHTER(0, "Пожарный", "Тренирован, вынослив и знает, с какой стороны браться за топор.",
            PzSkill.FITNESS, 6, PzSkill.STRENGTH, 6, PzSkill.SPRINTING, 1, PzSkill.AXE, 1),
    LUMBERJACK(0, "Лесоруб", "Валил деревья с утра до вечера.",
            PzSkill.STRENGTH, 6, PzSkill.AXE, 2, PzSkill.MAINTENANCE, 1),
    CONSTRUCTION(-2, "Строитель", "Молоток и лом - продолжение рук.",
            PzSkill.SHORT_BLUNT, 2, PzSkill.LONG_BLUNT, 1, PzSkill.MAINTENANCE, 1),
    DIY_EXPERT(-2, "Мастер на все руки", "Всё чинит сам и бережёт инструмент.",
            PzSkill.MAINTENANCE, 2, PzSkill.SHORT_BLUNT, 1),
    FISHING_GUIDE(-2, "Рыболовный гид", "Водил туристов к лучшим местам клёва.",
            PzSkill.FISHING, 3),
    SECURITY_GUARD(-2, "Охранник", "Ночные обходы, дубинка и привычка двигаться тихо.",
            PzSkill.SPRINTING, 2, PzSkill.LIGHTFOOTED, 1, PzSkill.SHORT_BLUNT, 1),
    POLICE_OFFICER(-4, "Полицейский", "Стрелковая подготовка и умение уворачиваться.",
            PzSkill.AIMING, 4, PzSkill.NIMBLE, 1),
    BURGLAR(-6, "Взломщик", "Привык входить туда, где его не ждут, и уходить незамеченным.",
            PzSkill.NIMBLE, 2, PzSkill.SNEAKING, 2, PzSkill.LIGHTFOOTED, 2),
    FITNESS_INSTRUCTOR(-6, "Фитнес-тренер", "Лучшая физическая форма во всём округе.",
            PzSkill.FITNESS, 8, PzSkill.STRENGTH, 6, PzSkill.SPRINTING, 2),
    VETERAN(-8, "Ветеран", "Прошёл войну. Оружие в руках не дрожит.",
            PzSkill.AIMING, 2);

    public final int points;        // очки на черты: + даёт, - забирает (как в PZ)
    public final String title;
    public final String description;
    public final Map<PzSkill, Integer> levels = new EnumMap<>(PzSkill.class);

    Profession(int points, String title, String description, Object... pairs) {
        this.points = points;
        this.title = title;
        this.description = description;
        for (int i = 0; i + 1 < pairs.length; i += 2) levels.put((PzSkill) pairs[i], (Integer) pairs[i + 1]);
    }

    /** Стартовый уровень навыка: Сила и Форма по умолчанию 5, остальное 0. */
    public int start(PzSkill s) {
        Integer v = levels.get(s);
        if (v != null) return v;
        return s.passive() ? 5 : 0;
    }

    public static Profession byIndex(int i) {
        Profession[] a = values();
        return i >= 0 && i < a.length ? a[i] : UNEMPLOYED;
    }
}
