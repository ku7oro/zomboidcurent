package com.example.zomboidmod;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.List;
import java.util.function.Supplier;

/** Бытовой лут: консервы, еда, напитки, изолента, книги навыков. */
public final class LootItems {
    public static Item CAN_OPENER, CANNED_BEANS, CANNED_SOUP, CANNED_TUNA, OPEN_BEANS, OPEN_SOUP, OPEN_TUNA;
    public static Item CHIPS, CHOCOLATE, CEREAL, SODA, WATER_BOTTLE, DUCT_TAPE;
    public static Item BOOK_FIRST_AID, BOOK_COOKING, BOOK_FARMING, BOOK_FISHING;

    private LootItems() {
    }

    private static Item reg(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
    }

    private static Item.Settings food(int nutrition, float sat) {
        return new Item.Settings().maxCount(16).food(new FoodComponent.Builder().nutrition(nutrition).saturationModifier(sat).build());
    }

    public static void register() {
        CAN_OPENER = reg("can_opener", new Hint(new Item.Settings().maxDamage(80), "Открывает консервы"));
        OPEN_BEANS = reg("open_beans", new FoodDrink(food(7, 0.7f), 0, "Открытая банка"));
        OPEN_SOUP = reg("open_soup", new FoodDrink(food(5, 0.6f), 15, "Открытая банка. Утоляет и жажду"));
        OPEN_TUNA = reg("open_tuna", new FoodDrink(food(6, 0.8f), 0, "Открытая банка"));
        CANNED_BEANS = reg("canned_beans", new Canned(new Item.Settings().maxCount(16), () -> OPEN_BEANS));
        CANNED_SOUP = reg("canned_soup", new Canned(new Item.Settings().maxCount(16), () -> OPEN_SOUP));
        CANNED_TUNA = reg("canned_tuna", new Canned(new Item.Settings().maxCount(16), () -> OPEN_TUNA));
        CHIPS = reg("chips", new FoodDrink(food(3, 0.2f), -3, "Солёные: хочется пить"));
        CHOCOLATE = reg("chocolate", new FoodDrink(food(4, 0.4f), 0, "Сладкое, быстро насыщает"));
        CEREAL = reg("cereal", new FoodDrink(food(5, 0.5f), 0, "Сухой завтрак"));
        SODA = reg("soda", new Drink(new Item.Settings().maxCount(16), 25, 1, "Газировка: +25% к воде"));
        WATER_BOTTLE = reg("water_bottle", new Drink(new Item.Settings().maxCount(16), 45, 0, "Чистая вода: +45% к воде"));
        DUCT_TAPE = reg("duct_tape", new DuctTape(new Item.Settings().maxCount(16)));
        BOOK_FIRST_AID = reg("book_first_aid", new SkillBook(new Item.Settings().maxCount(1), PzSkill.FIRST_AID, "Справочник по первой помощи"));
        BOOK_COOKING = reg("book_cooking", new SkillBook(new Item.Settings().maxCount(1), PzSkill.COOKING, "Домашняя кулинария"));
        BOOK_FARMING = reg("book_farming", new SkillBook(new Item.Settings().maxCount(1), PzSkill.FARMING, "Огород и сад"));
        BOOK_FISHING = reg("book_fishing", new SkillBook(new Item.Settings().maxCount(1), PzSkill.FISHING, "Рыбалка для начинающих"));
    }

    public static List<Item> all() {
        return List.of(CAN_OPENER, CANNED_BEANS, CANNED_SOUP, CANNED_TUNA, OPEN_BEANS, OPEN_SOUP, OPEN_TUNA, CHIPS, CHOCOLATE,
                CEREAL, SODA, WATER_BOTTLE, DUCT_TAPE, BOOK_FIRST_AID, BOOK_COOKING, BOOK_FARMING, BOOK_FISHING);
    }

    /** Случайный том книги (чем выше, тем реже), как в лутe PZ. */
    public static void randomVolume(ItemStack st, Random r) {
        if (!(st.getItem() instanceof SkillBook)) return;
        float k = r.nextFloat();
        int vol = k < 0.4f ? 1 : (k < 0.65f ? 2 : (k < 0.83f ? 3 : (k < 0.94f ? 4 : 5)));
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, st, nbt -> nbt.putInt("vol", vol));
    }

    // ===== классы =====

    static class Hint extends Item {
        final String hint;

        Hint(Settings s, String hint) {
            super(s);
            this.hint = hint;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(hint).formatted(Formatting.GRAY));
        }
    }

    /** Еда, которая меняет воду (суп утоляет жажду, чипсы наоборот). */
    static class FoodDrink extends Hint {
        final int thirst;

        FoodDrink(Settings s, int thirst, String hint) {
            super(s, hint);
            this.thirst = thirst;
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (!world.isClient && thirst != 0 && user instanceof ServerPlayerEntity p) ZomboidMod.addThirst(p, thirst);
            return super.finishUsing(stack, world, user);
        }
    }

    /** Напиток: восполняет воду. */
    static class Drink extends Hint {
        final int water, food;

        Drink(Settings s, int water, int food, String hint) {
            super(s, hint);
            this.water = water;
            this.food = food;
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.DRINK;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return 32;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            user.setCurrentHand(hand);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                ZomboidMod.addThirst(p, water);
                if (food > 0) p.getHungerManager().add(food, 0.1f);
            }
            stack.decrementUnlessCreative(1, user);
            return stack;
        }
    }

    /** Закрытая консерва: нужен консервный нож (или нож - но можно и порезаться). */
    static class Canned extends Hint {
        final Supplier<Item> opened;

        Canned(Settings s, Supplier<Item> opened) {
            super(s, "Нужен консервный нож (или нож)");
            this.opened = opened;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack stack = user.getStackInHand(hand);
            if (world.isClient) return TypedActionResult.pass(stack);
            ItemStack tool = find(user, CAN_OPENER);
            boolean knife = false;
            if (tool.isEmpty()) {
                tool = find(user, ZomboidMod.KITCHEN_KNIFE);
                if (tool.isEmpty()) tool = find(user, ZomboidMod.HUNTING_KNIFE);
                knife = !tool.isEmpty();
            }
            if (tool.isEmpty()) {
                user.sendMessage(Text.literal("Нечем открыть: нужен консервный нож"), true);
                return TypedActionResult.fail(stack);
            }
            tool.damage(knife ? 3 : 1, user, EquipmentSlot.MAINHAND);
            if (knife && user instanceof ServerPlayerEntity p && p.getRandom().nextFloat() < 0.2f) {
                Wounds.addWound(p, p.getRandom().nextBoolean() ? BodyPart.L_HAND : BodyPart.R_HAND, WoundType.SCRATCH);
            }
            world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_IRON_TRAPDOOR_OPEN, SoundCategory.PLAYERS, 0.5f, 1.6f);
            stack.decrementUnlessCreative(1, user);
            user.getInventory().offerOrDrop(new ItemStack(opened.get()));
            return TypedActionResult.success(stack);
        }

        private static ItemStack find(PlayerEntity p, Item item) {
            for (int i = 0; i < p.getInventory().size(); i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (s.isOf(item)) return s;
            }
            return ItemStack.EMPTY;
        }
    }

    /** Изолента: держите в одной руке, а повреждённое оружие в другой - восстановит четверть прочности. */
    static class DuctTape extends Hint {
        DuctTape(Settings s) {
            super(s, "Чинит оружие во второй руке");
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack tape = user.getStackInHand(hand);
            ItemStack target = user.getStackInHand(hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND);
            if (world.isClient) return TypedActionResult.pass(tape);
            if (target.isEmpty() || !target.isDamageable() || !target.isDamaged()) {
                user.sendMessage(Text.literal("Возьмите повреждённое оружие во вторую руку"), true);
                return TypedActionResult.fail(tape);
            }
            int fix = Math.max(1, target.getMaxDamage() / 4);
            target.setDamage(Math.max(0, target.getDamage() - fix));
            world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_LEATHER.value(), SoundCategory.PLAYERS, 0.8f, 1.2f);
            if (user instanceof ServerPlayerEntity p) Skills.addXp(p, PzSkill.MAINTENANCE, 5f);
            tape.decrementUnlessCreative(1, user);
            return TypedActionResult.success(tape);
        }
    }

    /** Книга навыка, как в PZ: том N ускоряет опыт на своих уровнях. Книга не тратится. */
    public static class SkillBook extends Item {
        static final float[] MULT = {3, 5, 8, 12, 16};
        final PzSkill skill;
        final String title;

        SkillBook(Settings s, PzSkill skill, String title) {
            super(s);
            this.skill = skill;
            this.title = title;
        }

        static int vol(ItemStack st) {
            NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
            int v = c == null ? 1 : c.copyNbt().getInt("vol");
            return Math.max(1, Math.min(5, v == 0 ? 1 : v));
        }

        @Override
        public Text getName(ItemStack stack) {
            return Text.literal(title + ", том " + vol(stack));
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            int v = vol(stack);
            tooltip.add(Text.literal(skill.title + ": опыт x" + (int) MULT[v - 1] + " на уровнях " + (2 * v - 1) + "-" + (2 * v))
                    .formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Зажмите ПКМ, чтобы прочитать").formatted(Formatting.DARK_GRAY));
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return 80;
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.NONE;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            user.setCurrentHand(hand);
            if (!world.isClient) user.sendMessage(Text.literal("Читаете..."), true);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                int v = vol(stack);
                Skills.readBook(p, skill, v);
                p.sendMessage(Text.literal("Прочитано: " + skill.title + " - опыт x" + (int) MULT[v - 1] + " на уровнях "
                        + (2 * v - 1) + "-" + (2 * v)), false);
                world.playSound(null, p.getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.PLAYERS, 1f, 1f);
            }
            return stack;
        }
    }
}
