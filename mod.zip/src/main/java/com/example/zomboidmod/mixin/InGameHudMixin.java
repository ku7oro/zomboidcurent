package com.example.zomboidmod.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Прячет ванильные сердца, еду и броню: в PZ вместо полосок - мудлы и панель здоровья. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderHealthBar", at = @At("HEAD"), cancellable = true)
    private void zomboid$hideHearts(CallbackInfo ci) {
        ci.cancel();
    }

    /** Шкала еды скрыта: голод показывает мудл. */
    @Inject(method = "renderFood", at = @At("HEAD"), cancellable = true)
    private void zomboid$hideFood(CallbackInfo ci) {
        ci.cancel();
    }

    /** Шкала брони скрыта. */
    @Inject(method = "renderArmor", at = @At("HEAD"), cancellable = true)
    private static void zomboid$hideArmor(CallbackInfo ci) {
        ci.cancel();
    }
}
