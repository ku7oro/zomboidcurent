package com.example.zomboidmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Навыки и профессии игроков хранятся в мире. */
public class SkillState extends PersistentState {
    public final Map<UUID, PlayerSkills> players = new HashMap<>();

    private static final PersistentState.Type<SkillState> TYPE =
            new PersistentState.Type<>(SkillState::new, SkillState::fromNbt, null);

    public static SkillState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "zomboidmod_skills");
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        NbtCompound all = new NbtCompound();
        players.forEach((id, s) -> all.put(id.toString(), s.toNbt()));
        nbt.put("players", all);
        return nbt;
    }

    public static SkillState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        SkillState st = new SkillState();
        NbtCompound all = nbt.getCompound("players");
        for (String key : all.getKeys()) st.players.put(UUID.fromString(key), PlayerSkills.fromNbt(all.getCompound(key)));
        return st;
    }
}
