package com.example.zomboidmod;

import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Топоры: сильный медленный удар, рубят деревья. */
public class PzAxeItem extends AxeItem {
    private final boolean heavy;

    public PzAxeItem(ToolMaterial material, float totalDamage, float attackSpeed, int durability, boolean heavy,
                     Settings settings) {
        super(material, settings.maxDamage(durability).attributeModifiers(AxeItem.createAttributeModifiers(
                material, totalDamage - 1 - material.getAttackDamage(), attackSpeed)));
        this.heavy = heavy;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal(heavy ? "Двуручный: страшный, но медленный удар" : "Рубящее, рубит деревья")
                .formatted(Formatting.GRAY));
    }

    /** Уход за оружием: с шансом удар не отнимает прочность. */
    public void postDamageEntity(ItemStack stack, net.minecraft.entity.LivingEntity target, net.minecraft.entity.LivingEntity attacker) {
        if (Skills.saveDurability(attacker)) return;
        super.postDamageEntity(stack, target, attacker);
    }
}
