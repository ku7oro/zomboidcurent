package com.example.zomboidmod;

import net.minecraft.util.math.random.Random;

/** Повадки зомби (как в Project Zomboid): шатун, быстрый шатун, бегун, ползун. */
public enum ZombieKind {
    SHAMBLER("Шатун", 0.17, 0.17, 20, 60),
    FAST_SHAMBLER("Быстрый шатун", 0.23, 0.23, 20, 25),
    SPRINTER("Бегун", 0.17, 0.36, 16, 8),   // идёт шагом, пока не заметил жертву, потом бежит
    CRAWLER("Ползун", 0.04, 0.04, 12, 7);   // ползёт примерно в 5 раз медленнее

    public final String title;
    public final double idleSpeed;
    public final double chaseSpeed;
    public final int health;
    public final int weight;

    ZombieKind(String title, double idleSpeed, double chaseSpeed, int health, int weight) {
        this.title = title;
        this.idleSpeed = idleSpeed;
        this.chaseSpeed = chaseSpeed;
        this.health = health;
        this.weight = weight;
    }

    public static ZombieKind random(Random r) {
        int total = 0;
        for (ZombieKind k : values()) total += k.weight;
        int n = r.nextInt(total);
        for (ZombieKind k : values()) {
            n -= k.weight;
            if (n < 0) return k;
        }
        return SHAMBLER;
    }
}
