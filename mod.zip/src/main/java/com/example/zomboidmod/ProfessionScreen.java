package com.example.zomboidmod;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Создание персонажа как в PZ: шаг 1 - профессия, шаг 2 - черты характера за очки.
 * Закрыть без выбора нельзя.
 */
public class ProfessionScreen extends Screen {
    private int step = 0;
    private int selected = 0;
    private long traits = 0L;

    private int listX, listY;
    private static final int ROW = 11;
    private static final int LIST_W = 150;
    private int btnX, btnY, backX;
    private static final int BTN_W = 90;

    // шаг 2: колонки черт
    private record Cell(PzTrait t, int x, int y, int w) {}
    private final List<Cell> cells = new ArrayList<>();

    public ProfessionScreen() {
        super(Text.literal("Новый персонаж"));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean shouldPause() {
        return true;
    }

    private Profession prof() {
        return Profession.values()[selected];
    }

    private static String pts(int p) {
        return p > 0 ? "+" + p : String.valueOf(p);
    }

    private int[] window() {
        int winW = Math.min(this.width - 12, 440);
        int winH = Math.min(this.height - 12, Profession.values().length * ROW + 64);
        return new int[]{(this.width - winW) / 2, (this.height - winH) / 2, winW, winH};
    }

    private void frame(DrawContext ctx, int wx, int wy, int winW, int winH, String title) {
        ctx.fill(wx - 1, wy - 1, wx + winW + 1, wy + winH + 1, 0xFF6E6E6E);
        ctx.fill(wx, wy, wx + winW, wy + winH, 0xF0121212);
        ctx.fill(wx, wy, wx + winW, wy + 16, 0xFF262626);
        ctx.drawTextWithShadow(this.textRenderer, title, wx + 6, wy + 4, 0xFFFFFF);
    }

    private void button(DrawContext ctx, int mx, int my, int x, int y, String label, boolean enabled, int col) {
        boolean over = enabled && mx >= x && mx < x + BTN_W && my >= y && my < y + 16;
        ctx.fill(x - 1, y - 1, x + BTN_W + 1, y + 17, 0xFF8A8A8A);
        ctx.fill(x, y, x + BTN_W, y + 16, !enabled ? 0xFF2A2A2A : (over ? brighten(col) : col));
        ctx.drawCenteredTextWithShadow(this.textRenderer, label, x + BTN_W / 2, y + 4, enabled ? 0xFFFFFF : 0x777777);
    }

    private static int brighten(int c) {
        return 0xFF000000 | (Math.min(255, ((c >> 16) & 255) + 30) << 16) | (Math.min(255, ((c >> 8) & 255) + 30) << 8)
                | Math.min(255, (c & 255) + 30);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int[] w = window();
        int wx = w[0], wy = w[1], winW = w[2], winH = w[3];
        btnX = wx + winW - BTN_W - 8;
        btnY = wy + winH - 22;
        backX = btnX - BTN_W - 8;
        if (step == 0) renderProfessions(ctx, mx, my, wx, wy, winW, winH);
        else renderTraits(ctx, mx, my, wx, wy, winW, winH);
    }

    // ===== шаг 1 =====
    private void renderProfessions(DrawContext ctx, int mx, int my, int wx, int wy, int winW, int winH) {
        frame(ctx, wx, wy, winW, winH, "Новый персонаж (1/2): профессия");
        Profession[] all = Profession.values();
        listX = wx + 8;
        listY = wy + 24;
        for (int i = 0; i < all.length; i++) {
            int y = listY + i * ROW;
            boolean over = mx >= listX && mx < listX + LIST_W && my >= y && my < y + ROW;
            if (i == selected) ctx.fill(listX, y, listX + LIST_W, y + ROW, 0xFF3C3C3C);
            else if (over) ctx.fill(listX, y, listX + LIST_W, y + ROW, 0xFF262626);
            ctx.drawTextWithShadow(this.textRenderer, all[i].title, listX + 4, y + 2, i == selected ? 0xFFFFFF : 0xBBBBBB);
            String p = pts(all[i].points);
            ctx.drawTextWithShadow(this.textRenderer, p, listX + LIST_W - 4 - this.textRenderer.getWidth(p), y + 2,
                    all[i].points >= 0 ? 0x88EE88 : 0xFF8888);
        }

        Profession p = prof();
        int ix = listX + LIST_W + 12, iw = wx + winW - ix - 8;
        int ty = listY;
        ctx.drawTextWithShadow(this.textRenderer, p.title, ix, ty, 0xFFD54A);
        ty += 14;
        for (var line : this.textRenderer.wrapLines(Text.literal(p.description), iw)) {
            ctx.drawTextWithShadow(this.textRenderer, line, ix, ty, 0xCCCCCC);
            ty += 10;
        }
        ty += 6;
        ctx.drawTextWithShadow(this.textRenderer, "Очки на черты: " + pts(p.points), ix, ty, p.points >= 0 ? 0x88EE88 : 0xFF8888);
        ty += 14;
        ctx.drawTextWithShadow(this.textRenderer, "Стартовые навыки:", ix, ty, 0xFFFFFF);
        ty += 12;
        if (p.levels.isEmpty()) {
            ctx.drawTextWithShadow(this.textRenderer, "нет", ix + 6, ty, 0x888888);
            ty += 11;
        }
        for (Map.Entry<PzSkill, Integer> e : p.levels.entrySet()) {
            ctx.drawTextWithShadow(this.textRenderer, e.getKey().title + ": " + e.getValue(), ix + 6, ty, 0x88EE88);
            ty += 11;
        }
        button(ctx, mx, my, btnX, btnY, "Далее", true, 0xFF2C5A2A);
    }

    // ===== шаг 2 =====
    private void renderTraits(DrawContext ctx, int mx, int my, int wx, int wy, int winW, int winH) {
        frame(ctx, wx, wy, winW, winH, "Новый персонаж (2/2): черты характера");
        int balance = PzTrait.balance(prof(), traits);
        String bl = "Очки: " + pts(balance);
        ctx.drawTextWithShadow(this.textRenderer, bl, wx + winW - 8 - this.textRenderer.getWidth(bl), wy + 4,
                balance >= 0 ? 0x88EE88 : 0xFF6666);

        cells.clear();
        int colW = (winW - 24) / 3;
        int x0 = wx + 8, y0 = wy + 22;
        ctx.drawTextWithShadow(this.textRenderer, "Положительные (тратят очки)", x0, y0, 0x88EE88);
        ctx.drawTextWithShadow(this.textRenderer, "Отрицательные (дают очки)", x0 + 2 * (colW + 4), y0, 0xFF8888);
        int pi = 0, ni = 0;
        int rows = Math.max(1, (winH - 22 - 12 - 46) / 10);   // не залезать на подсказку внизу
        for (PzTrait t : PzTrait.values()) {
            int x, y;
            if (t.positive()) {
                int col = pi / rows;
                x = x0 + col * (colW + 4);
                y = y0 + 12 + (pi % rows) * 10;
                pi++;
            } else {
                x = x0 + 2 * (colW + 4);
                y = y0 + 12 + ni * 10;
                ni++;
            }
            cells.add(new Cell(t, x, y, colW));
        }

        PzTrait hover = null;
        for (Cell c : cells) {
            boolean on = PzTrait.has(traits, c.t());
            boolean blocked = !on && blocked(c.t());
            boolean over = mx >= c.x() && mx < c.x() + c.w() && my >= c.y() && my < c.y() + 10;
            if (on) ctx.fill(c.x(), c.y(), c.x() + c.w(), c.y() + 10, c.t().positive() ? 0xFF2C5A2A : 0xFF6A2424);
            else if (over && !blocked) ctx.fill(c.x(), c.y(), c.x() + c.w(), c.y() + 10, 0xFF2A2A2A);
            int col = blocked ? 0x555555 : (on ? 0xFFFFFF : 0xBBBBBB);
            GuiUtil.smallText(ctx, this.textRenderer, c.t().title, c.x() + 3, c.y() + 2, col);
            String cost = String.valueOf(Math.abs(c.t().cost));
            GuiUtil.smallText(ctx, this.textRenderer, cost, c.x() + c.w() - 3 - Math.round(this.textRenderer.getWidth(cost) * 0.75f),
                    c.y() + 2, blocked ? 0x555555 : (c.t().positive() ? 0x88EE88 : 0xFF8888));
            if (over) hover = c.t();
        }

        // подсказка внизу
        int hy = wy + winH - 40;
        ctx.fill(wx + 8, hy - 2, wx + winW - 8, hy - 1, 0xFF333333);
        if (hover != null) {
            ctx.drawTextWithShadow(this.textRenderer, hover.title + ": " + hover.description, wx + 8, hy + 2, 0xDDDDDD);
            if (!PzTrait.has(traits, hover) && blocked(hover)) {
                GuiUtil.smallText(ctx, this.textRenderer, "Несовместима с уже выбранной чертой", wx + 8, hy + 13, 0xFF8888);
            }
        } else {
            GuiUtil.smallText(ctx, this.textRenderer, "Наведите на черту, чтобы прочитать. Щелчок - выбрать или убрать.", wx + 8, hy + 4, 0x888888);
        }

        button(ctx, mx, my, backX, btnY, "Назад", true, 0xFF3A3A3A);
        button(ctx, mx, my, btnX, btnY, "Начать", balance >= 0, 0xFF2C5A2A);
    }

    private boolean blocked(PzTrait t) {
        for (PzTrait x : t.exclusive()) if (PzTrait.has(traits, x)) return true;
        return false;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        boolean onBtn = mx >= btnX && mx < btnX + BTN_W && my >= btnY && my < btnY + 16;
        boolean onBack = mx >= backX && mx < backX + BTN_W && my >= btnY && my < btnY + 16;
        if (step == 0) {
            Profession[] all = Profession.values();
            if (mx >= listX && mx < listX + LIST_W && my >= listY) {
                int i = (int) ((my - listY) / ROW);
                if (i >= 0 && i < all.length) {
                    selected = i;
                    return true;
                }
            }
            if (onBtn) {
                step = 1;
                return true;
            }
        } else {
            for (Cell c : cells) {
                if (mx >= c.x() && mx < c.x() + c.w() && my >= c.y() && my < c.y() + 10) {
                    if (PzTrait.has(traits, c.t())) traits &= ~c.t().bit();
                    else if (!blocked(c.t())) traits |= c.t().bit();
                    return true;
                }
            }
            if (onBack) {
                step = 0;
                return true;
            }
            if (onBtn && PzTrait.valid(prof(), traits)) {
                ClientPlayNetworking.send(new SkillPayloads.Choose(selected, traits));
                ZomboidClient.professionChosenLocally();
                this.close();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
